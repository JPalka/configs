README_bindos.txt for version 8.2 of Vim: Vi IMproved.

See "README.txt" for general information about Vim.
See "README_dos.txt" for installation instructions for MS-DOS and MS-Windows.
These files are in the runtime archive (vim82rt.zip).


There are several binary distributions of Vim for the PC.  You would normally
pick only one of them, but it's also possible to install several.
These ones are available (the version number may differ):
	vim82w32.zip	Windows 95/98/NT/etc. console version
	gvim82.zip	Windows 95/98/NT/etc. GUI version
	gvim82ole.zip	Windows 95/98/NT/etc. GUI version with OLE

You MUST also get the runtime archive (vim82rt.zip).
The sources are also available (vim82src.zip).
